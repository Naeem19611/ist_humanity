<?php include 'template/header.php'; ?>
<?php 
    $name = "";
    $designation = "";
    $profession = "";
    $education = "";
    $address = "";
    $joining_date = "";
    $phone = "";
    $email = "";
    $nid = "";
    $status = "";
    $department = "";

    
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = mysqli_real_escape_string($conn,data_filter($_POST['name']));
        $designation = mysqli_real_escape_string($conn,data_filter($_POST['designation']));
        $profession = mysqli_real_escape_string($conn,data_filter($_POST['profession']));
        $education = mysqli_real_escape_string($conn,data_filter($_POST['education']));
        $address = mysqli_real_escape_string($conn,data_filter($_POST['address']));
        $phone = mysqli_real_escape_string($conn,data_filter($_POST['phone']));
        $nid = mysqli_real_escape_string($conn,data_filter($_POST['nid']));
        $department = mysqli_real_escape_string($conn,data_filter($_POST['department']));
        $email = mysqli_real_escape_string($conn,data_filter($_POST['email']));
        $joining_date = mysqli_real_escape_string($conn,data_filter($_POST['joining_date']));
        $status = mysqli_real_escape_string($conn,data_filter($_POST['status']));
        
        
        $image = $_FILES['image']['name'];
        $target_dr_name = "upload/staff/";
        $target_file_dr_image = $target_dr_name . basename($_FILES['image']['name']);
        
        // Select file type
        $imageFileType = strtolower(pathinfo($target_file_dr_image, PATHINFO_EXTENSION));
        
        // valid file extansion
        $extentsions_arr = array("jpg","jepg","png","gif");
        
        // Check extention is valid or not
        if(in_array($imageFileType, $extentsions_arr)) {
            
            // Upload file
            $is_upload_dr_image = move_uploaded_file($_FILES['image']['tmp_name'], $target_dr_name.$image);
            
            if($is_upload_dr_image) {
                
                // Deprtment Add Query
                $sql_serv_insert = "INSERT INTO stuff (dept_id, name, designation, image, profession, edu_background, joining_date, address, phone, email, nid, stauts)
                 VALUES ($department, '$name', '$designation', '$image', '$profession', '$education', '$joining_date', '$address', '$phone', '$email', '$nid', $status)";
                $sql_serv_result = $conn->query($sql_serv_insert);

                if($sql_serv_result === TRUE) {
                  echo "<script>alert('New staff Added Sucessfully');</script>";  
                } else {
                  //echo "<script>alert('Sorry ! Could not add the staff, Try Again');</script>"; 
                  echo $sql_serv_insert;
                }
            } else {
                echo "<script>alert('Sorry ! Could not upload image, Try Again');</script>";  
            }
        } else {
           echo "<script>alert('Sorry ! Inalid extension detected, Try Again');</script>"; 
        }  
    }
    
    // Data validation or filter function
    function data_filter($data) {
        $data = trim($data);
        $data = stripcslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    } 
?>
<div class="page-wrapper">
    <div class="content">
        <div>
            <h1 class="mt-4">Add Staff</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Add Staff</li>
            </ol>
        </div>
        <div style="margin: 15px;" class="row">
            <div class="col-md-6">
                <form action="" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                      <label>Staff Name</label>
                      <input type="text" class="form-control" name="name" placeholder="Write staff name.." required>
                    </div>

                    <div class="form-group">
                      <label>Designation</label>
                      <input type="text" class="form-control" name="designation" placeholder="Write staff designation.." required>
                    </div>

                    <div class="form-group">
                      <label>Staff Image</label>
                      <input type="file" class="form-control border" name="image" >
                    </div>

                    <div class="form-group">
                      <label>Profession</label>
                      <input type="text" class="form-control" name="profession" placeholder="Write profession.." required>
                    </div>

                    <div class="form-group">
                      <label>Education Background</label>
                      <input type="text" class="form-control" name="education" placeholder="Write education background.." required>
                    </div>

                    <div class="form-group">
                      <label>Address</label>
                      <textarea class="form-control" rows="8" name="address" placeholder="Write address .." required></textarea>
                    </div>
                    <button type="submit" name="submit" class="btn btn-primary">Submit</button>    
            </div>

                <div class='col-md-6'>
                    

                <div class="form-group">
                        <label>Department</label>
                        <select name='department' class="form-control">
                          <option value='0'>Select Department</option>
                          <?php
                              $sql = "select * from department";
                              $table = mysqli_query($conn, $sql);
                              while($row = mysqli_fetch_assoc($table))
                              {
                                echo "<option value='".$row['id']."'>{$row['dept_name']}</option>";
                              }
                          ?>   
                        </select>
                    </div>

                    

                    <div class="form-group">
                      <label>phone</label>
                      <input type="text" class="form-control" name="phone" placeholder="Write phone number..">
                    </div>

                    <div class="form-group">
                      <label>Email</label>
                      <input type="text" class="form-control" name="email" placeholder="Write email..">
                    </div>

                    <div class="form-group">
                      <label>Joining Date</label>
                      <input type="text" class="form-control" name="joining_date" placeholder="Write joining date..">
                    </div>

                    <div class="form-group">
                      <label>NID Number</label>
                      <input type="text" class="form-control" name="nid" placeholder="Write NID number..">
                    </div>

                    

                    <div class="form-group">
                        <label>Status</label>
                        <select name='status' class="form-control">
                            <option value='1'>Active</option>
                            <option value='0'>DeActive</option>
                        </select>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include 'template/footer.php'; ?>

